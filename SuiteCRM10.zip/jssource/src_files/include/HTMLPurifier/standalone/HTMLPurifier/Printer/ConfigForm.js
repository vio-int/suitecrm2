function toggleWriteability(id_of_patient, checked) {
    document.getElementById(id_of_patient).disabled = checked;
}

// vim: et sw=4 sts=4
