#Callables
Add callable to the Slim Framework here

Example:

`
$app->add('ResourceServer');
`