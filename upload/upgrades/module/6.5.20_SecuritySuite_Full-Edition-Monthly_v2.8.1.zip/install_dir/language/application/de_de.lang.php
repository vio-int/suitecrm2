<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Berechtigungsgruppen';
$app_strings['LBL_LOGIN_AS'] = "Einloggen als ";
$app_strings['LBL_LOGOUT_AS'] = "Ausloggen als ";
$app_strings['LBL_SECURITYGROUP'] = 'Berechtigungsgruppe';

?>