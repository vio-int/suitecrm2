﻿<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Управління Групами Користувачів';
$app_strings['LBL_LOGIN_AS'] = "Ввійти як ";
$app_strings['LBL_LOGOUT_AS'] = "Вийти як ";
$app_strings['LBL_SECURITYGROUP'] = 'Управління Групами';
?>
