<?php

$mod_strings['LBL_ACCESS_GROUP'] = 'Group';
$mod_strings['LBL_ACTION_CREATE'] = 'Create';

