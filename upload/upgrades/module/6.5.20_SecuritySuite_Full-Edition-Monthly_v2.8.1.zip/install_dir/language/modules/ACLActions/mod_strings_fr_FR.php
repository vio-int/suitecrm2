<?php

$mod_strings['LBL_ACCESS_GROUP'] = 'Equipes';
$mod_strings['LBL_ACTION_CREATE'] = 'Cr�er';

