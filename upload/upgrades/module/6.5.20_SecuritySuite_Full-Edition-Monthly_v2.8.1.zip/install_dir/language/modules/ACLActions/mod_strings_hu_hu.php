<?php

$mod_strings['LBL_ACCESS_GROUP'] = 'Csoport';
$mod_strings['LBL_ACTION_CREATE'] = 'L�trehoz�sa';

