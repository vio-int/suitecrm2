﻿<?php

$mod_strings['LBL_ACCESS_GROUP'] = 'Группа';$mod_strings['LBL_ACTION_CREATE'] = 'Создать';

