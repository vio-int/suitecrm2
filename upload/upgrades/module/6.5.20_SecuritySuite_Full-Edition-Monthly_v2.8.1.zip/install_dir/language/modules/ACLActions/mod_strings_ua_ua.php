﻿<?php

$mod_strings['LBL_ACCESS_GROUP'] = 'Група';$mod_strings['LBL_ACTION_CREATE'] = 'створити';

