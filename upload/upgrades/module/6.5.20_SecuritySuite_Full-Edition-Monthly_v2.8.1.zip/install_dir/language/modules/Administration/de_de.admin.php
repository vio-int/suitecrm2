<?php

$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Berechtigungsgruppen Verwaltung';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Berechtigungsgruppen bearbeiten';
$mod_strings['LBL_SECURITYGROUPS'] = 'Berechtigungsgruppen';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Berechtigungsgruppen Einstellungen';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Die Einstellungen für Berechtigungsgruppen anpassen - Vererbungsregeln, additive Rechte etc.';
$mod_strings['LBL_SECURITYGROUPS'] = 'Berechtigungsgruppen';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Jetzt alle Features!";
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO'] = "Starten Sie profitiert von den vielen Funktionen, die Premium-Security kommen mit schnellen einschließlich Debugging, benutzerdefinierte Gruppe Layouts und mehr.";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Dokumentation";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Erfahren Sie mehr über die vielen Funktionen und Optionen, Security kommt verpackt mit.";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Nachrichten Dashlet verteilen";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Machen Sie das Nachrichten Dashlet auf der Startseite aller Benutzer sichtbar. Dieser Vorgang kann, abhängig von der Anzahl der Benutzer, ein bisschen dauern.";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Modul verbinden";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Selbst erstellte Module mit Berechtigungsgruppen verbinden";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters.com";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Weitere handverlesene Lösungen für die Community Edition.";
$mod_strings['LBL_SECURITYGROUPS_LICENSE_TITLE'] = 'Lizenzkonfiguration';
$mod_strings['LBL_SECURITYGROUPS_LICENSE'] = 'Verwalten und konfigurieren Sie die Lizenz für dieses Modul';

