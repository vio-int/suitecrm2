<?php

$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Gerenciamento do Módulo de Grupos de Segurança';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Editor do Módulo de Grupos de Segurança';
$mod_strings['LBL_SECURITYGROUPS'] = 'Módulo de Grupos de Segurança';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Configurações do Módulo de Grupos de Segurança';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Configurações do Gerenciador do Módulo de Grupos de Segurança como herança, aditivo de segurança, etc';
$mod_strings['LBL_SECURITYGROUPS'] = 'Módulo de Grupos de Segurança';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Obter todos os recursos!";
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO'] = "Comece beneficiando das muitas características que SecuritySuite premium vêm com incluindo depuração rápida, layouts grupo personalizado e muito mais.";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Documentação";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Saiba mais sobre os diversos recursos e opções que SecuritySuite vem embalado com.";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Empurre a mensagem Dashlet";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Push the Message Dashlet to the Home page for all users. This process may take some time to complete depending on the number of users";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Módulo da conexão";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Série da Grupos de Segurança a trabalhar com seus módulos feitos sob encomenda";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters.com";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Veja as soluções mais escolhidos a dedo para Community Edition.";
$mod_strings['LBL_SECURITYGROUPS_LICENSE_TITLE'] = 'Configuración de licencias';
$mod_strings['LBL_SECURITYGROUPS_LICENSE'] = 'Administrar y configurar la licencia para este módulo';
