﻿<?php

$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Управление Группами пользователей';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Редактор Групп пользователей';
$mod_strings['LBL_SECURITYGROUPS'] = 'Группы пользователей';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Настройки Групп пользователей';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Конфигурирование настроек Групп пользователей';
$mod_strings['LBL_SECURITYGROUPS'] = 'Группы пользователей';

$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Получить все возможности!";

$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO'] = "Начните выгоду от многих функций, которые SecuritySuite Премиум приходят с включая быстрой отладки, пользовательские группы макетов, и многое другое.";

$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "документация";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Узнайте больше о многих функций и опций, что SecuritySuite поставляется упакованной с.";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Push Message Dashlet";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Push the Message Dashlet to the Home page for all users. This process may take some time to complete depending on the number of users";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Hookup Module";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Hookup Security Suite to work with your custom modules";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters.com";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Подробнее подобранных решений для Community Edition.";
$mod_strings['LBL_SECURITYGROUPS_LICENSE_TITLE'] = 'Конфигурация Лицензия';
$mod_strings['LBL_SECURITYGROUPS_LICENSE'] = 'Управление и настройка лицензию на это дополнение';?>
