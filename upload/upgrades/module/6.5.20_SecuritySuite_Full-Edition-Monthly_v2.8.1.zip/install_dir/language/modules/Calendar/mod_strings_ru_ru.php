<?php

$mod_strings['LBL_SECURITYGROUPS'] = 'Фильтровать список Групп пользователей';
?>
