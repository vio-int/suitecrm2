<?php

$mod_strings['LBL_SECURITYGROUPS'] = 'Фільтр по Групам Користувачів';
?>
