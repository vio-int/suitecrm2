﻿<?php

$mod_strings['LBL_DEFAULT'] = 'По умолчанию';
$mod_strings['LBL_ADD_LAYOUT'] = 'Добавить макет';
$mod_strings['LBL_ADD_LAYOUTS'] = 'Добавить макет';
$mod_strings['LBL_QUESTION_ADD_LAYOUT'] = 'Выбрать макет Групп для добавления.';
$mod_strings['LBL_REMOVE_LAYOUT'] = 'Удалить макет Групп';

$mod_strings['LBL_SECURITYGROUP'] = 'Группы пользователей:';
$mod_strings['LBL_COPY_FROM'] = 'Копировать из:';
$mod_strings['LBL_ADDLAYOUTDONE'] = 'Сохраненный макет';
$mod_strings['LBL_REMOVELAYOUTDONE'] = 'Удаленный макет';
$mod_strings['LBL_REMOVE_CONFIRM'] = 'Вы действительно уверены?';
$mod_strings['help']['studioWizard']['addLayoutHelp'] = "Для создания макета Групп пользователей выберите соответствующую Группу и макет для копирования.";
$mod_strings['LBL_ADD_GROUP_LAYOUT'] = 'Добавить макет группы безопасности';

