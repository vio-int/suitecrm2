<?php

$mod_strings['LBL_LIST_NONINHERITABLE'] = "Pas de r�cup�ration de droits";
$mod_strings['LBL_PRIMARY_GROUP'] = "Groupe primaire";
