﻿<?php
$mod_strings['LBL_LIST_NONINHERITABLE'] = "Не наследуемая";
$mod_strings['LBL_PRIMARY_GROUP'] = "Основной группой";