﻿<?php

$mod_strings['LBL_LIST_NONINHERITABLE'] = 'Не успадковується';
$mod_strings['LBL_PRIMARY_GROUP'] = 'Основной группой';

