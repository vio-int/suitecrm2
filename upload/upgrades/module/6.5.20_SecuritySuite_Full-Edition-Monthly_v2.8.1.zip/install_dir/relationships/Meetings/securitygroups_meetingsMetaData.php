<?php

$dictionary['securitygroups_meetings'] = array ( ); 

?>
