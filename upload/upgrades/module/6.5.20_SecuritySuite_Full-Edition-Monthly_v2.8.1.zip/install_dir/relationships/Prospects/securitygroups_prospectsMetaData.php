<?php

$dictionary['securitygroups_prospects'] = array ( ); 

?>
