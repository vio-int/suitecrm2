<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$license_strings = array (
    'LBL_STEPS_TO_LOCATE_KEY_TITLE' => 'Om Uw sleutel Locate',
    'LBL_STEPS_TO_LOCATE_KEY' => '1. Log in om <a href="https://www.sugaroutfitters.com" target="_blank">SugarOutfitters</a><br/>2. Gaan naar Account->Purchases</br>3. Zoek de sleutel voor de aankoop van deze add-on<br/>4. Plakken in de Licentiecode vak hieronder<br/>5. Klik op "Validate"',
    'LBL_LICENSE_KEY' => 'Licentiecode',
    'LBL_CURRENT_USERS' => 'Huidige gebruiker Graaf',
    'LBL_LICENSED_USERS' => 'Licensed Gebruikersaantal',
    'LBL_VALIDATE_LABEL' => 'Bevestigen',
    'LBL_VALIDATED_LABEL' => 'Gevalideerd',
);

