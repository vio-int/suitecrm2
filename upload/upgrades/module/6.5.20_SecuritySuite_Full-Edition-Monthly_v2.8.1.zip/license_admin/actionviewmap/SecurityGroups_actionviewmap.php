<?php

$action_view_map['license'] = 'license';
